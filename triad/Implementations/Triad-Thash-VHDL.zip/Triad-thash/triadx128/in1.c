#include<stdio.h>
#include<time.h>
#include<stdlib.h>
#include<string.h>


 unsigned char ch(unsigned char u){

if (u >= '0' && u <='9') return u-'0'; 
if (u >= 'a' && u <='f') return 10+u-'a'; 
if (u >= 'A' && u <='F') return 10+u-'A'; 
}

  unsigned char rv(unsigned char u){

 
unsigned char a,b,c,d, e,f,g,h;

a=u & 1;
b=(u & 2) &&1;
c=(u & 4) &&1;
d=(u & 8) &&1;

return 8*a+4*b+2*c+d;
}


 unsigned char  rvb(unsigned char u){

 
unsigned char a,b,c,d, e,f,g,h;

a=u & 1;
b=(u & 2) &&1;
c=(u & 4) &&1;
d=(u & 8) &&1;
e=(u & 16) &&1; 
f=(u & 32) &&1;
g=(u & 64) &&1;
h=(u & 128) &&1;


return 16*(8*a+4*b+2*c+d) + (8*e+4*f+2*g+h);
}

main()

{
unsigned char a;
int i,j,k,sum=0,rem;
long long int read,byte,len;
char *line =NULL ;
 

FILE *fa,*fp,*fi,*fc;

fa=fopen("AD.txt","rb");
fp=fopen("PT.txt","rb");
fi=fopen("IN1.txt","wb");
fc=fopen("CS1.txt","wb");

for(i=0;i<200;i++)
{  sum=0;
   fprintf(fi,"%x",0x80 );
   for(j=0;j<127;j++) fprintf(fi,"%02x", 0 );sum+=256;
   for(j=0;j<128;j++) fprintf(fc,"%02x", 0 );

   read=getline(&line, &len, fa);
   if( !(line[0]=='N' && line[1]=='U' &&line[2]=='L' &&line[3]=='L') ){
   for(j=0;j<read-1;j+=2) {
   a=rv(ch(line[j+1]));
   fprintf(fi,"%x",a); 
   a=rv(ch(line[j]));
   fprintf(fi,"%x",a);sum+=2;

   fprintf(fc,"00");}
   byte=read/2;
   a=rvb( (byte)>>48);
   fprintf(fi,"%02x",a);
   a=rvb( (byte)>>40 & 0xff);
   fprintf(fi,"%02x",a);
   a=rvb( (byte)>>32 & 0xff);
   fprintf(fi,"%02x",a);
   a=rvb( (byte)>>24 & 0xff);
   fprintf(fi,"%02x",a);
   a=rvb( (byte)>>16 & 0xff);
   fprintf(fi,"%02x",a);
   a=rvb( (byte)>>8 & 0xff);
   fprintf(fi,"%02x",a);
   a=rvb( (byte)    & 0xff);
   fprintf(fi,"%02x",a);sum+=14;


   fprintf(fc,"%014x", 0 );
   }
   else {fprintf(fi,"%014x", 0 );fprintf(fc,"%014x", 0 ); sum+=14;}

   read=getline(&line, &len, fp);
   if(!(line[0]=='N' && line[1]=='U' &&line[2]=='L' &&line[3]=='L')){
   for(j=0;j<read-1;j+=2) {

   a=rv(ch(line[j+1]));
   fprintf(fi,"%x",a); 
   a=rv(ch(line[j]));
   fprintf(fi,"%x",a); sum+=2;

   fprintf(fc,"00");}
   }
 if(i==3)printf("%d ",sum);
   fprintf(fi,"%x",0x80 );
   for(j=0;j<135;j++) fprintf(fi,"%02x", 0 ); sum+=272;
   for(j=0;j<128;j++) fprintf(fc,"%02x", 0 );for(j=0;j<7;j++) fprintf(fc,"%02x", 0xff );
   fprintf(fc,"%02x", 0xfe );
   //if(i==0)printf("%d ",sum);
   if (sum%32!=0){
   
    rem=32-(sum%32);
    for(j=0;j<rem;j++){fprintf(fi,"0" );fprintf(fc,"0" );}
    
   }
//////////////////////////////////////////////////////////////// enc
sum=0;
if(!(line[0]=='N' && line[1]=='U' &&line[2]=='L' &&line[3]=='L')  ){
   fprintf(fi,"%x",0x80 );
   for(j=0;j<127;j++) fprintf(fi,"%02x", 0 );sum+=256;
   for(j=0;j<128;j++) fprintf(fc,"%02x", 0 );

   for(j=0;j<read-1;j+=2) {
   a=rv(ch(line[j+1]));
   fprintf(fi,"%x",a); 
   a=rv(ch(line[j]));
   fprintf(fi,"%x",a);sum+=2;

   }
   for(j=0;j<read-2;j++) fprintf(fc,"f");
   fprintf(fc,"e");

   if (sum%32!=0){
   
    rem=32-(sum%32);
    for(j=0;j<rem;j++){fprintf(fi,"0" );fprintf(fc,"0" );}
    
   }
   }
    fprintf(fi,"\n");
    fprintf(fc,"\n");

 }


 
}
